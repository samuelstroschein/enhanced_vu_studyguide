module.exports = {
  svelteSortOrder: "script-markup-styles",
  svelteStrictMode: false,
  svelteBracketNewLine: true,
};
