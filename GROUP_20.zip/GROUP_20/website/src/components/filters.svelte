<div>
  <div>
    <FilterPeriod />
  </div>
  <div>
    <FilterLevel />
  </div>
  <div>
    <FilterEC />
  </div>
  <div>
    <FilterLang />
  </div>
  <div>
    <FilterProf />
  </div>
</div>

<script>
  import FilterPeriod from "../components/filters/period_filter.svelte";
  import FilterLevel from "../components/filters/level_filter.svelte";
  import FilterEC from "../components/filters/ec_filter.svelte";
  import FilterProf from "../components/filters/prof_filter.svelte";
  import FilterLang from "../components/filters/lang_filter.svelte";
</script>
