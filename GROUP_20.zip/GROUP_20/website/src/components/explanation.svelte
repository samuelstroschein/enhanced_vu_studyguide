<p>This app was created in order to demonstrate SPARQL. </p>
<p>Above you can select multiple filters in order to search for extracurricular courses at the Vrije Universiteit Amsterdam.</p>
<p>By default the amount of results are limited to 800, this is only changeable in the code. This limitation was put in place because Vercel does not allow queries that take longer than 10 seconds to process.</p>
<!-- <p>Created by: Benn Samuel Stroschein, Tim Brandt Corstius, Satiga Godrie, Azra Çinar</p> Removed for privacy -->