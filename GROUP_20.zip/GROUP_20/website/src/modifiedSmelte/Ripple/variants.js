module.exports = {
  all: color => [
    `bg-${color}-trans`,
    `bg-${color}-transDark`,
    `hover:bg-${color}-trans`,
    `hover:bg-${color}-transDark`
  ]
};
