import Ripple from "./Ripple.svelte";

export default Ripple;
