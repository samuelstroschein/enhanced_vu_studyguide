module.exports = {
  all: () => [`pl-4`, `pl-8`, `pl-12`]
};
