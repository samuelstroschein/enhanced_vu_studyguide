
### Build & Run the project

```bash
npm install
npm run dev
```

Open up [localhost:3000](http://localhost:3000) and start clicking around.

### Export static site

```bash
npm run export
```
